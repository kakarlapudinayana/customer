package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bean.Customerbean;
import com.capgemini.dao.CustomerDaoImpl;
//import com.capgemini.donorapplication.exception.DonorException;
import com.capgemini.exception.CustomersException;

public class CustomerDaoTest {

	static CustomerDaoImpl dao;
	static Customerbean customer;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new CustomerDaoImpl();
		customer = new Customerbean();
	}

	@Test
	public void testAddCustomerDetails() throws CustomersException {

		assertNotNull(dao.addCustomerDetails(customer));

	}            
	

	

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddCustomerDetails1() throws CustomersException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addCustomerDetails(customer));
		
	}
	

}